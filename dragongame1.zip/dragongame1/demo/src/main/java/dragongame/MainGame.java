package dragongame;

public class MainGame {
	// Huvudmetod som startar spelet
	public static void main(String[] args) {
		GameEngine game = new GameEngine();
		game.playGame();
	}
}